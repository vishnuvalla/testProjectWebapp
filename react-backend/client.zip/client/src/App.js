import React, { Component } from 'react';
import './App.css';

class App extends Component {
  state = { transactions: [] }

  componentDidMount() {
    fetch('http://localhost:3001')
      .then(response => console.log(response))
      .then(({response}) => this.setState({transactions: 'response'}))
      .catch(error => console.log(error));
  }

  render() {
    return (
      <div className="App">

      </div>
    );
  }
}

export default App;
